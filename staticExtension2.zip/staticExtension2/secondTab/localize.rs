﻿package custom.extensionnamemin.secondTab;

/***************************************************************************
 * Filters
 ***************************************************************************/
$filters {
    english "Filters";
}
$extensionnamemin {
    english "ExtensionName";
}
$extensionnameminPicklistTip {
    english "Picklist";
}
$extensionnameminViewRectList {
    english "View Rect";
}

$categoryFilter {
    english "Category";
}
$collectionFilter {
    english "Collection";
}
$categoriesall {
    english "All";
}

$collectionsall {
    english "All";
}

$productnamemin {
    english "productName";
}

$ProductNameMay {
    english "productName";
}

$productName {
    english "productName";
}




/***************************************************************************
***************************************************************************
 Library
 ***************************************************************************
 ***************************************************************************/

/***************************************************************************
 * Props
 ***************************************************************************/
$width {
    english "Width";
}
$depth {
    english "Depth";
}
$height {
    english "Height";
}
$lenght {
    english "Length";
}
$handSide {
    english "Hand Side";
}
$finish {
    english "Finish";
}
$color {
    english "Finish Color";
}
$diameter  {
    english "Diameter";
}


/***************************************************************************
 * Enums
 ***************************************************************************/
