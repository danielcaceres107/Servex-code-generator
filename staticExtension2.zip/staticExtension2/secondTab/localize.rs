﻿package custom.extensionnamemin.secondTab;

/***************************************************************************
 * Filters
 ***************************************************************************/
$extensionnamemin {
    english "ExtensionName";
}
$extensionnameminPicklistTip {
    english "Picklist";
}
$extensionnameminViewRectList {
    english "View Rect";
}

$filters {
    english "Filters";
}
$categoryFilter {
    english "Category";
}
$collectionFilter {
    english "Collection";
}


$allCategSC {
    english "All";
}

$allCollect {
    english "All";
}

$chairsSC {
    english "Chairs";
}
$standsSC {
    english "Stands";
}
$stoolsSC {
    english "Stools";
}
$tablesSC {
    english "Tables";
}

/**
 * Chairs
 */
$chairsMusic {
    english "Music Chairs";
}

/***************************************************************************
***************************************************************************
 Library
 ***************************************************************************
 ***************************************************************************/

/***************************************************************************
 * Chairs
 ***************************************************************************/

/**
 * Music Chairs
 */
$CM_8210 {
    english "NPS® 8200 Series Melody Music Chair";
}



/***************************************************************************
 * Props
 ***************************************************************************/
$width {
    english "Width";
}
$depth {
    english "Depth";
}
$height {
    english "Height";
}
$lenght {
    english "Length";
}
$handSide {
    english "Hand Side";
}
$finish {
    english "Finish";
}
$color {
    english "Finish Color";
}
$diameter  {
    english "Diameter";
}


/***************************************************************************
 * Enums
 ***************************************************************************/
$chairsHandSide.left {
    english "Left";
}
$chairsHandSide.right {
    english "Right";
}

$chairsPaddedMat.vinyl {
    english "Vinil";
}
$chairsPaddedMat.fabric {
    english "Fabric";
}

$stoolsColor.grey {
    english "Grey";
}
$stoolsColor.black {
    english "Black";
}
$stoolsArtFinish.steel {
    english "Steel";
}
$stoolsArtFinish.wood {
    english "Wood";
}
$stoolsArtFinish.fabric {
    english "Fabric";
}

$stoolIndustrialArm.no {
    english "No";
}
$stoolIndustrialArm.yes {
    english "Yes";
}

$stoolsCafeFinish.steel {
    english "Steel";
}
$stoolsCafeFinish.wood {
    english "Wood";
}
$backRestFinish.yes {
    english "Add Backrest";
}
$backRestFinish.no {
    english "No Backrest";
}
$typeStoolFinish.fixed {
    english "Fixed";
}
$typeStoolFinish.adjustable {
    english "Adjustable";
}
$filters {
    english "Filters";
}
